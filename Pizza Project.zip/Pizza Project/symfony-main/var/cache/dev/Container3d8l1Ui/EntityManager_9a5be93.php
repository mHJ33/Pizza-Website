<?php

namespace Container3d8l1Ui;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'src'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder443bd = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializer623e1 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties91237 = [
        
    ];

    public function getConnection()
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'getConnection', array(), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'getMetadataFactory', array(), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'getExpressionBuilder', array(), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'beginTransaction', array(), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->beginTransaction();
    }

    public function getCache()
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'getCache', array(), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->getCache();
    }

    public function transactional($func)
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'transactional', array('func' => $func), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'wrapInTransaction', array('func' => $func), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'commit', array(), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->commit();
    }

    public function rollback()
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'rollback', array(), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'getClassMetadata', array('className' => $className), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'createQuery', array('dql' => $dql), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'createNamedQuery', array('name' => $name), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'createQueryBuilder', array(), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'flush', array('entity' => $entity), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'clear', array('entityName' => $entityName), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->clear($entityName);
    }

    public function close()
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'close', array(), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->close();
    }

    public function persist($entity)
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'persist', array('entity' => $entity), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'remove', array('entity' => $entity), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'refresh', array('entity' => $entity), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'detach', array('entity' => $entity), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'merge', array('entity' => $entity), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'getRepository', array('entityName' => $entityName), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'contains', array('entity' => $entity), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'getEventManager', array(), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'getConfiguration', array(), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'isOpen', array(), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'getUnitOfWork', array(), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'getProxyFactory', array(), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'initializeObject', array('obj' => $obj), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'getFilters', array(), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'isFiltersStateClean', array(), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'hasFilters', array(), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return $this->valueHolder443bd->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializer623e1 = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolder443bd) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder443bd = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder443bd->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, '__get', ['name' => $name], $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        if (isset(self::$publicProperties91237[$name])) {
            return $this->valueHolder443bd->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder443bd;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder443bd;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, '__set', array('name' => $name, 'value' => $value), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder443bd;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder443bd;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, '__isset', array('name' => $name), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder443bd;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder443bd;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, '__unset', array('name' => $name), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder443bd;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder443bd;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, '__clone', array(), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        $this->valueHolder443bd = clone $this->valueHolder443bd;
    }

    public function __sleep()
    {
        $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, '__sleep', array(), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;

        return array('valueHolder443bd');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializer623e1 = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializer623e1;
    }

    public function initializeProxy() : bool
    {
        return $this->initializer623e1 && ($this->initializer623e1->__invoke($valueHolder443bd, $this, 'initializeProxy', array(), $this->initializer623e1) || 1) && $this->valueHolder443bd = $valueHolder443bd;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder443bd;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder443bd;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
